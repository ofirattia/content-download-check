var getUrlParameter = function (sParam) {
    var sPageURL = window.location.search.substring(1),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            // alert("found param");
            return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
        }
    }
};

var app = {
    // Application Constructor
    initialize: function() {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function() {
        app.receivedEvent('deviceready');
        console.log('Running cordova-' + cordova.platformId + '@' + cordova.version);
        document.getElementById('deviceready').classList.add('ready');
    },
    
    // Update DOM on a Received Event
    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');

        console.log('Received Event: ' + id);

        document.getElementById("syncBtn").onclick = this.sync;
        document.getElementById("downloadExtractBtn").onclick = this.download;
        
        var sync = ContentSync.sync({id: 'myapp', type: 'local'});
        sync.on('complete', function(data) {
            if(data.localPath) {
                console.log(data.localPath);
                console.log(data);
                // alert(data.cached);
              var url = "file://"+data.localPath + "/contentZip/www/index.html";
              //alert('Sync complete ' + data + ' changing document.location ' + url );
              // document.location = url;
              var params = getUrlParameter("cached");
                console.log(params);
                if (params) {
                  return;
                }
              // alert(url+"?cached=true");
              ContentSync.loadUrl(url+"?cached=true");
            }
        });
        sync.on('error', function(e) {
          alert('no synced app. Loading main app');
        });
    },

    setProgress: function(progress) {
        if(progress.status) {
            switch(progress.status) {
                case 1:
                    document.getElementById('status').innerHTML = "Downloading...";
                    break;
                case 2:
                    document.getElementById('status').innerHTML = "Extracting...";
                    break;
                case 3:
                    document.getElementById('status').innerHTML = "Complete!";
                    break;
                default:
                    document.getElementById('status').innerHTML = "";
            }
        }
        if(progress.progress) {
            var progressBar = document.getElementById('progressbar').children[0];
            progressBar.style.width = progress.progress + '%';
        }
     },


    sync: function() {
        //alert("sync clicked");
        //var url = "https://github.com/timkim/zipTest/archive/master.zip";
        var url = "http://localhost:8080/api/users/downloadZip";
        var sync = ContentSync.sync({ src: url, id: 'myapp', type: 'merge', copyCordovaAssets: true, copyRootApp: false, headers: false, trustHost: true });
        //var sync = ContentSync.sync({ src: null, id: 'myapp', type: 'local', copyRootApp: true });
        //var sync = ContentSync.sync({ src: url, id: 'myapp', type: 'replace', copyCordovaAssets: true });

        var setProgress = this.setProgress;

        sync.on('progress', function(progress) {
            console.log("Progress event", progress);
            app.setProgress(progress);
        });
        sync.on('complete', function(data) {
            console.log("Complete", data);
            ContentSync.loadUrl("file://"+data.localPath + "/contentZip/www/index.html");
            document.location = data.localPath + "/contentZip/www/index.html";
        });

        sync.on('error', function(e) {
            console.log("Something went wrong: ", e);
            document.getElementById('status').innerHTML = e;
        });
    },
    download: function() {
        // document.getElementById("downloadExtractBtn").disabled = true;
        var url = "http://localhost:8080/api/users/downloadZip";
        var extract = this.extract;
        var setProgress = this.setProgress;
        var callback = function(response) {
            console.log(response);
            if(response.progress) {
                app.setProgress(response);

            }
            if(response.archiveURL) {
                var archiveURL = response.archiveURL;
               document.getElementById("downloadExtractBtn").disabled = false;
               document.getElementById("downloadExtractBtn").innerHTML = "Extract";
               document.getElementById("downloadExtractBtn").onclick = function() {
                    app.extract(archiveURL);
               };
               document.getElementById("status").innerHTML = archiveURL;
            }
        };
        ContentSync.download(url, callback);
    },
    extract: function(archiveURL) {
        window.requestFileSystem(PERSISTENT, 1024 * 1024, function(fs) {
            fs.root.getDirectory('zipOutPut', {create: true}, function(fileEntry) {
                var dirUrl = fileEntry.toURL();
                var callback = function(response) {
                    console.log(response);
                    document.getElementById("downloadExtractBtn").style.display = "none";
                    document.getElementById("status").innerHTML = "Extracted";
                }
                console.log(dirUrl, archiveURL);
                Zip.unzip(archiveURL, dirUrl, callback);
            });
        });
    }
};

app.initialize();
